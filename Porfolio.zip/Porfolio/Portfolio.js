import React, { useRef } from "react";
import './App.css';
import image from "./ce.jpg"
import code from "./fed.jpeg"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBolt, faDownload, faFileDownload, faHouse, faPaperPlane } from "@fortawesome/free-solid-svg-icons";
import { faEnvelope, faUser, faUserCircle } from "@fortawesome/free-regular-svg-icons";
import { faFacebook, faGithub, faInstagram, faLinkedin, faYoutube } from "@fortawesome/free-brands-svg-icons";
import { useState } from "react";


function App(){
 const [inputs, setInputs] = useState({
    name:"",
    email:"",
    subject:"",
    message:""
  })
  const handleChange = (e)=>{
    const {id,value} = e.target;
    setInputs(prev =>({...prev,[id]:value}))
  }

const handleSubmit = (e)=>{
   e.preventDefault();
   console.log("Name:",inputs.name);
   console.log("Email:",inputs.email);
   console.log("Subject:",inputs.subject);
   console.log("Message:",inputs.message);
   
   setInputs({
    name:'',
    email:'',
    subject:'',
    message:''
   })
}
    const downloadfile = ()=>{
        window.location.href="https://github.com/AravindanS04/Resume-For-FED.git"
    }
    return(
        <div id="body">
            <nav id="nav">
        <a href="#name" id="home"><FontAwesomeIcon icon={faHouse} id="house"></FontAwesomeIcon>Home</a>
        <a href="#about" id="about"><FontAwesomeIcon icon={faUserCircle} id="user"></FontAwesomeIcon>About</a>
        <a href="#skills" id="myskills"><FontAwesomeIcon icon={faBolt} id="skills"></FontAwesomeIcon> My Skills</a>
        <a href="#contact" id="contact"><FontAwesomeIcon icon={faEnvelope} id="reach"></FontAwesomeIcon>Contact</a>
    </nav>
    <header>
       <h1 id="name">I'm Aravindan.</h1> 
       <h3>Civil Engineer and Web Designer.</h3>
        <img src={image} alt="CE image" id="ce"></img>
        <img src={code} alt="code image" id="code"></img>
       
    </header>
    <article>
        <h2 id="about">About</h2>
        <p id="para">I'm a front-end developer and committed civil engineer who loves creating both digital and physical worlds. With a strong background in structural design, construction planning, and geotechnical analysis, I bring a detail-oriented approach and problem-solving abilities to every engineering project.<br/>I specialize in creating responsive, user-friendly online interfaces with HTML, CSS, JavaScript, and contemporary frameworks like React in addition to my work in civil engineering. I appreciate combining technological precision with creative design to create seamless digital experiences.
</p>
    </article>
    <aside>
        <button id="resume" onClick={downloadfile}><FontAwesomeIcon icon={faDownload} id="download"></FontAwesomeIcon> Download Resume</button>
    </aside>
    <section>
        <h2 id="skills">My Skills</h2>  
        <p id="skill-civil">Civil Engineer</p>
        <div id="skill">
        <div id="civil" ></div></div>
        <p id="skill-web">Web Designer</p>
        <div id="skill">
        <div id="web"></div></div>
    </section>
    <footer>
        <h2 id="contact">For Contact</h2>
        <p>Phone: 9876543210</p>
        <a href="mailto:XYZ@gmail.com" id="mail">Email : XYZ@gmail.com</a>
        <p>Let's get in touch. Send me a message</p>

    <form id="form" onSubmit={handleSubmit}>
        <input 
        type="text"
        placeholder="Name" 
        id="name" 
        name="name"
        value={inputs.name}
        
        onChange={handleChange} 
        required></input>
        <input type="email" 
        placeholder="Email" 
        id="email" 
        name="email"  
        value={inputs.email}
        required onChange={handleChange}></input>
        <input type="text" 
        placeholder="Subject" 
        id="subject" 
        required 
        name="subject"  
        value={inputs.subject}
        maxLength={60}onChange={handleChange}></input>
        <input type="text" 
        placeholder="Message" 
        id="message" 
        value={inputs.message}
        required name="message" 
        onChange={handleChange}></input></form>
        <button id="send" onClick={handleSubmit}><FontAwesomeIcon icon={faPaperPlane} id="msg"></FontAwesomeIcon> Send Message</button><br/>
        <a href="#" id="fb"><FontAwesomeIcon icon={faFacebook} id="face"></FontAwesomeIcon></a>
        <a href="#" id="yt"><FontAwesomeIcon icon={faYoutube} id="you"></FontAwesomeIcon></a>
        <a href="#" id="insta"><FontAwesomeIcon icon={faInstagram} id="ins"></FontAwesomeIcon></a>
        <a href="https://www.linkedin.com/in/aravindan-s-799a43282?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" id="li"><FontAwesomeIcon icon={faLinkedin} id="lin"></FontAwesomeIcon></a>
        <a href="https://github.com/AravindanS04" id="github" target="_blank"><FontAwesomeIcon icon={faGithub} id="git"></FontAwesomeIcon></a>

    </footer>
        </div>
    ) 
}
export default App